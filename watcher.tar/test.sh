#!/bin/bash
if egrep "BROKEN" $1; then
    sleep 5
    echo "uh, oh" >&2
    mv $1 $1.fail
    exit 1
fi
sleep 3
echo "loaded $1"
mv $1 $1.done
exit 0
